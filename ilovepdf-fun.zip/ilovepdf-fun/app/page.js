"use client";
// app/page.js — Homepage

import Link from "next/link";
import AdBanner from "@/components/AdBanner";
import { useLang } from "@/components/Providers";

// Tool definitions — icon paths inline SVG, color tokens
const TOOLS = [
  {
    slug:       "merge",
    titleKey:   "tool_merge_title",
    descKey:    "tool_merge_desc",
    color:      "var(--brand)",
    bg:         "var(--brand-light)",
    group:      "organize",
    icon: (c) => (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none"
           stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M8 6H6a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V8a2 2 0 00-2-2h-2"/>
        <path d="M8 6V4a2 2 0 012-2h4a2 2 0 012 2v2M8 6h8"/>
        <line x1="12" y1="11" x2="12" y2="17"/>
        <line x1="9"  y1="14" x2="15" y2="14"/>
      </svg>
    ),
  },
  {
    slug:       "split",
    titleKey:   "tool_split_title",
    descKey:    "tool_split_desc",
    color:      "var(--brand)",
    bg:         "var(--brand-light)",
    group:      "organize",
    icon: (c) => (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none"
           stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"/>
        <polyline points="14 2 14 8 20 8"/>
        <line x1="9" y1="15" x2="15" y2="15"/>
      </svg>
    ),
  },
  {
    slug:       "compress",
    titleKey:   "tool_compress_title",
    descKey:    "tool_compress_desc",
    color:      "var(--amber)",
    bg:         "var(--amber-light)",
    group:      "organize",
    icon: (c) => (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none"
           stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <polyline points="21 8 21 21 3 21 3 8"/>
        <rect x="1" y="3" width="22" height="5"/>
        <line x1="10" y1="12" x2="14" y2="12"/>
      </svg>
    ),
  },
  {
    slug:       "rotate",
    titleKey:   "tool_rotate_title",
    descKey:    "tool_rotate_desc",
    color:      "var(--amber)",
    bg:         "var(--amber-light)",
    group:      "organize",
    icon: (c) => (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none"
           stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <polyline points="1 4 1 10 7 10"/>
        <path d="M3.51 15a9 9 0 102.13-9.36L1 10"/>
      </svg>
    ),
  },
  {
    slug:       "delete-pages",
    titleKey:   "tool_delete_title",
    descKey:    "tool_delete_desc",
    color:      "var(--blue)",
    bg:         "var(--blue-light)",
    group:      "organize",
    icon: (c) => (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none"
           stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <polyline points="3 6 5 6 21 6"/>
        <path d="M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6"/>
        <path d="M10 11v6M14 11v6"/>
        <path d="M9 6V4a1 1 0 011-1h4a1 1 0 011 1v2"/>
      </svg>
    ),
  },
  {
    slug:       "remove-password",
    titleKey:   "tool_unlock_title",
    descKey:    "tool_unlock_desc",
    color:      "var(--green)",
    bg:         "var(--green-light)",
    group:      "security",
    icon: (c) => (
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none"
           stroke={c} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
        <path d="M7 11V7a5 5 0 019.9-1"/>
      </svg>
    ),
  },
];

function ToolCard({ tool }) {
  const { t } = useLang();
  return (
    <Link
      href={`/tools/${tool.slug}`}
      className="card-hover"
      style={{
        display: "block",
        background: "var(--surface)",
        border: "1px solid var(--border)",
        borderRadius: "var(--r-lg)",
        padding: "20px 18px 18px",
      }}
    >
      {/* Icon badge */}
      <div style={{
        width: 42,
        height: 42,
        background: tool.bg,
        borderRadius: "var(--r-sm)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        marginBottom: 14,
      }}>
        {tool.icon(tool.color)}
      </div>

      <h2 style={{ fontSize: 14, fontWeight: 600, color: "var(--text-1)", marginBottom: 5, lineHeight: 1.3 }}>
        {t(tool.titleKey)}
      </h2>
      <p style={{ fontSize: 12, color: "var(--text-3)", lineHeight: 1.4 }}>
        {t(tool.descKey)}
      </p>
    </Link>
  );
}

export default function HomePage() {
  const { t } = useLang();

  const titleLines = t("hero_title").split("\n");

  return (
    <div className="container" style={{ paddingTop: 56, paddingBottom: 60 }}>

      {/* ── Hero ── */}
      <div style={{ textAlign: "center", marginBottom: 40 }}>
        <h1 style={{
          fontSize: "clamp(28px, 5vw, 38px)",
          fontWeight: 700,
          letterSpacing: "-0.6px",
          lineHeight: 1.15,
          marginBottom: 14,
        }}>
          {titleLines.map((line, i) => (
            <span key={i}>
              {i === 0
                ? <>{line.replace("PDF", "")}<span style={{ color: "var(--brand)" }}>PDF</span></>
                : line}
              {i < titleLines.length - 1 && <br />}
            </span>
          ))}
        </h1>
        <p style={{
          fontSize: 16,
          color: "var(--text-2)",
          lineHeight: 1.65,
          maxWidth: 440,
          margin: "0 auto",
        }}>
          {t("hero_sub").split("\n").map((line, i) => (
            <span key={i}>{line}{i === 0 && <br />}</span>
          ))}
        </p>
      </div>

      {/* ── Top ad ── */}
      <AdBanner slot="1111111111" style={{ marginBottom: 36 }} />

      {/* ── Tool grid ── */}
      <div style={{
        display: "grid",
        gridTemplateColumns: "repeat(3, 1fr)",
        gap: 12,
        marginBottom: 36,
      }}>
        {TOOLS.map((tool) => <ToolCard key={tool.slug} tool={tool} />)}
      </div>

      {/* ── Mid ad ── */}
      <AdBanner slot="2222222222" style={{ marginBottom: 40 }} />

      {/* ── Trust strip ── */}
      <div style={{
        display: "flex",
        justifyContent: "center",
        flexWrap: "wrap",
        gap: "12px 32px",
        padding: "20px 0 32px",
        borderTop: "1px solid var(--border)",
        borderBottom: "1px solid var(--border)",
        marginBottom: 40,
      }}>
        {[t("trust_1"), t("trust_2"), t("trust_3")].map((text) => (
          <div key={text} style={{
            display: "flex",
            alignItems: "center",
            gap: 7,
            fontSize: 13,
            color: "var(--text-2)",
            fontWeight: 500,
          }}>
            <span style={{
              width: 7,
              height: 7,
              borderRadius: "50%",
              background: "var(--green-bright)",
              flexShrink: 0,
            }} />
            {text}
          </div>
        ))}
      </div>

      {/* ── Why section (SEO) ── */}
      <div style={{
        background: "var(--surface)",
        border: "1px solid var(--border)",
        borderRadius: "var(--r-xl)",
        padding: "28px 32px",
      }}>
        <h2 style={{ fontSize: 18, fontWeight: 600, marginBottom: 10 }}>
          {t("why_title")}
        </h2>
        <p style={{ fontSize: 14, color: "var(--text-2)", lineHeight: 1.75 }}>
          {t("why_body")}
        </p>
      </div>

    </div>
  );
}
