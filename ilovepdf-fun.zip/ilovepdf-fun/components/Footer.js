"use client";
// components/Footer.js

import Link from "next/link";
import { useLang } from "./Providers";

export default function Footer() {
  const { t } = useLang();

  return (
    <footer style={{
      background: "var(--surface)",
      borderTop: "1px solid var(--border)",
      padding: "28px 24px",
      marginTop: 48,
    }}>
      <div style={{
        maxWidth: 780,
        margin: "0 auto",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        gap: 10,
        textAlign: "center",
      }}>

        {/* Logo small */}
        <div style={{ display: "flex", alignItems: "center", gap: 2, fontWeight: 700, fontSize: 16 }}>
          <span>i</span>
          <span style={{
            width: 17, height: 17,
            background: "var(--brand)",
            borderRadius: "50%",
            display: "inline-flex",
            alignItems: "center",
            justifyContent: "center",
            margin: "0 2px",
          }}>
            <svg width="8" height="8" viewBox="0 0 24 24" fill="white">
              <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5
                       2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09
                       C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5
                       c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
            </svg>
          </span>
          <span>PDF</span>
          <span style={{ color: "var(--text-3)", fontWeight: 500, fontSize: 13 }}>.fun</span>
        </div>

        <p style={{ fontSize: 13, color: "var(--text-3)" }}>
          © {new Date().getFullYear()} ilovepdf.fun — {t("footer_rights")}
        </p>

        <p style={{ fontSize: 12, color: "var(--text-3)" }}>
          🔒 {t("footer_privacy")}
        </p>

        <div style={{ display: "flex", gap: 20, marginTop: 4 }}>
          <Link href="/imprint" style={{ fontSize: 13, color: "var(--text-2)" }}>
            {t("imprint")}
          </Link>
          <Link href="/privacy" style={{ fontSize: 13, color: "var(--text-2)" }}>
            {t("privacy")}
          </Link>
        </div>

      </div>
    </footer>
  );
}
