"use client";
// components/Header.js

import Link from "next/link";
import { useLang } from "./Providers";
import { langNames, supportedLangs } from "@/lib/i18n";

export default function Header() {
  const { t, lang, switchLang } = useLang();

  return (
    <header style={{
      background: "var(--surface)",
      borderBottom: "1px solid var(--border)",
      height: 58,
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "0 28px",
      position: "sticky",
      top: 0,
      zIndex: 100,
    }}>

      {/* ── Logo: i ❤ PDF.fun ── */}
      <Link href="/" style={{
        display: "flex",
        alignItems: "center",
        gap: 2,
        fontWeight: 700,
        fontSize: 20,
        letterSpacing: "-0.3px",
        color: "var(--text-1)",
        userSelect: "none",
      }}>
        <span>i</span>

        {/* Red heart circle */}
        <span style={{
          width: 22,
          height: 22,
          background: "var(--brand)",
          borderRadius: "50%",
          display: "inline-flex",
          alignItems: "center",
          justifyContent: "center",
          margin: "0 2px",
          flexShrink: 0,
        }}>
          <svg width="11" height="11" viewBox="0 0 24 24" fill="white">
            <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5
                     2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09
                     C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5
                     c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
          </svg>
        </span>

        <span>PDF</span>
        <span style={{ color: "var(--text-3)", fontWeight: 500, fontSize: 16 }}>.fun</span>
      </Link>

      {/* ── Right side: nav + language switcher ── */}
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>

        {/* Nav links — hidden on very small screens via inline check */}
        <nav style={{ display: "flex", gap: 2 }}>
          {[
            { key: "nav_all",      href: "/" },
            { key: "nav_organize", href: "/#organize" },
            { key: "nav_security", href: "/#security" },
          ].map(({ key, href }) => (
            <Link
              key={key}
              href={href}
              style={{
                padding: "6px 12px",
                borderRadius: "var(--r-full)",
                fontSize: 13,
                fontWeight: 500,
                color: "var(--text-2)",
                transition: "background 0.12s, color 0.12s",
                whiteSpace: "nowrap",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = "var(--bg)";
                e.currentTarget.style.color = "var(--text-1)";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = "transparent";
                e.currentTarget.style.color = "var(--text-2)";
              }}
            >
              {t(key)}
            </Link>
          ))}
        </nav>

        {/* ── Language switcher ── */}
        <div style={{ display: "flex", gap: 4, marginLeft: 8 }}>
          {supportedLangs.map((l) => (
            <button
              key={l}
              onClick={() => switchLang(l)}
              style={{
                padding: "5px 10px",
                borderRadius: "var(--r-full)",
                fontSize: 12,
                fontWeight: 600,
                border: "1.5px solid",
                borderColor: lang === l ? "var(--brand)" : "var(--border)",
                background: lang === l ? "var(--brand)" : "transparent",
                color: lang === l ? "#fff" : "var(--text-2)",
                cursor: "pointer",
                transition: "all 0.15s",
                letterSpacing: "0.3px",
              }}
            >
              {langNames[l]}
            </button>
          ))}
        </div>
      </div>
    </header>
  );
}
